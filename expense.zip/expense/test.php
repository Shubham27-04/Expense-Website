<?php
// Start the session
session_start();

// Assuming you have validated the username during login
$_SESSION['username'] = 'john_doe'; // Set the username in the session

// Redirect to another page or display a success message
header('Location: welcome.php'); // Redirect to a welcome page
exit;
?>

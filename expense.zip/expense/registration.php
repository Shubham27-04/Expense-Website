<?php
// include('footer.php');
// include('header.php');
include('config.php');
if(isset($_POST['sbt']))
{
	$username=$_POST['username'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
	$address=$_POST['address'];
	$confirmpassword=$_POST['confirmpassword'];
	$password=$_POST['password'];
	if($password==$confirmpassword)
	{

		$sql="insert into register(username,email,mobile,address,password,role)values('$username','$email','$mobile','$address','$password','user')";
		$result=mysqli_query($con,$sql);
	}
	if($result)
		{
			
			echo "<script>alert('Registered Succesfully');
			window.location.href='login.php';</script>";
			header('location:index.php');
			
		}
	}

?>



